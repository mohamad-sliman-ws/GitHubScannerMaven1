
export class MethodNotImplementedException {

}